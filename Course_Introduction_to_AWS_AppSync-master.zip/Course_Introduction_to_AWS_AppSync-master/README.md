# Course_Introduction_to_AWS_AppSync
Learn to make the best use of managed services to build a GraphQL API

IMPORTANT
These files are distributed on an AS IS BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied
